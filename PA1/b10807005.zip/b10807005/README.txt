This assignment is done with VScode on windows. If configuration files are needed, please let me know and I will provide my full .vscode directory.
 
How to compile:
I compile my source code with mingw, I think it can also compile with the built-in GNU g++ compiler in linux.
Compile command is provided as follow:
g++ [-std=c++11 or later] [name_of_source_code]
ex:
g++ -std=c++17 main.cpp

How to run:
Execute command in the following format under directory "b10807005":
[name_of_executable_file] [input_file_name] [output_file_name]
ex:
main.exe 5000.in 5000.out

Student ID num.:B10807005
Name: 朱育辰
Language: C++
Compiler: MinGW g++ on windows
Compression: .zip file with 7-zip
Content:
	b10807005
		|
		|---main.exe:   executable binary
		|---main.cpp:   source code
		|---README.txt: this file